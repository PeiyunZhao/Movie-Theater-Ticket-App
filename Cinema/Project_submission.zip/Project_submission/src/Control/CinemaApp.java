package Control;

import View.WelcomeGUI;

public class CinemaApp {

	public static void main(String[] args) {
		WelcomeGUI welcomeGUI = new WelcomeGUI();
	}
}
